#include "stack.h"

typedef enum Object_type {BOOLEAN, FIXNUM, SYMBOL, EOF_OBJ};

typedef struct Object {
	Oject_type type;
	union {
		struct {
			
};
